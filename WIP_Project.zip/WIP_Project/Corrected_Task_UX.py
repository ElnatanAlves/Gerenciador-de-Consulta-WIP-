
import tkinter as tk
from tkinter import ttk, simpledialog, filedialog, messagebox
import sqlite3
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

class GerenciadorConsultas:
    def __init__(self, root):
        self.root = root
        self.root.title("Gerenciador de Consultas Médicas")
        self.root.geometry("800x600")
        self.root.configure(bg='#2D2D2D')  # Cor de fundo para o tema escuro

        # Configurar o estilo do treeview e dos botões
        self.style = ttk.Style()
        self.style.theme_use("clam")  # Tema que permite um estilo mais moderno

        # Configurações de estilo para o treeview
        self.style.configure("Treeview", font=('Helvetica', 12), background='#333333', 
                            foreground='white', fieldbackground='#2D2D2D')
        self.style.configure("Treeview.Heading", font=('Helvetica', 14, 'bold'), 
                            background='#555555', foreground='white')
        self.style.map('Treeview', background=[('selected', '#5F5F5F')])

        # Configurações de estilo para os botões
        self.style.configure('TButton', font=('Helvetica', 12), background='#333333', 
                            foreground='white')
        self.style.map('TButton', background=[('active', '#5F5F5F'), ('pressed', '#555555')])

        # Configurações de estilo para o Frame
        self.style.configure('TFrame', background='#2D2D2D')

        # Configurar o banco de dados
        self.setup_db()

        # Componentes da interface gráfica
        self.setup_widgets()

    # Métodos omitidos por brevidade.

# O código abaixo para iniciar a GUI será descomentado no script final.
root = tk.Tk()
app = GerenciadorConsultas(root)
root.mainloop()
