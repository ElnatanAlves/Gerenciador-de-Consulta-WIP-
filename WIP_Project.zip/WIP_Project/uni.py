import sqlite3
import tkinter as tk
from tkinter import ttk
import unittest

# Classe para gerenciar consultas médicas
class GerenciadorConsultas:
    def __init__(self, master):
        self.master = master
        self.master.title("Gerenciador de Consultas")
        
        self.conn = sqlite3.connect(":memory:")  # Usando banco em memória para simplicidade
        self.cursor = self.conn.cursor()
        self._setup_db()
        
        self.tree = ttk.Treeview(master, columns=("paciente", "medico", "data", "hora"))
        self.tree.heading("#0", text="ID")
        self.tree.heading("paciente", text="Paciente")
        self.tree.heading("medico", text="Médico")
        self.tree.heading("data", text="Data")
        self.tree.heading("hora", text="Hora")
        self.tree.grid(row=0, column=0, sticky="nsew")

    def _setup_db(self):
        self.cursor.execute("""
        CREATE TABLE consultas (
            id INTEGER PRIMARY KEY,
            paciente TEXT,
            medico TEXT,
            data TEXT,
            hora TEXT
        )
        """)

    def adicionar_consulta(self, consulta):
        self.cursor.execute("""
            INSERT INTO consultas(paciente, medico, data, hora)
            VALUES(:paciente, :medico, :data, :hora)
        """, consulta)
        self.conn.commit()

    def carregar_consultas(self):
        self.cursor.execute("SELECT * FROM consultas")
        rows = self.cursor.fetchall()
        for row in rows:
            self.tree.insert('', 'end', text=row[0], values=row[1:])

# Classe para testar o gerenciamento de consultas
class TestGerenciadorConsultas(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.gerenciador = GerenciadorConsultas(self.root)

    def test_adicionar_e_carregar_consultas(self):
        consultas_esperadas = [
            {'paciente': 'Paciente 1', 'medico': 'Médico 1', 'data': '01/01/2021', 'hora': '08:00'},
            {'paciente': 'Paciente 2', 'medico': 'Médico 2', 'data': '02/01/2021', 'hora': '09:00'},
        ]
        for consulta in consultas_esperadas:
            self.gerenciador.adicionar_consulta(consulta)

        self.gerenciador.carregar_consultas()

        consultas_carregadas = [self.gerenciador.tree.item(child)["values"] for child in self.gerenciador.tree.get_children()]
        self.assertEqual(len(consultas_carregadas), len(consultas_esperadas))
        for esperado, carregado in zip(consultas_esperadas, consultas_carregadas):
            self.assertListEqual([esperado['paciente'], esperado['medico'], esperado['data'], esperado['hora']], carregado)

    def tearDown(self):
        self.gerenciador.conn.close()
        self.root.destroy()

# Código para executar a interface gráfica, se executado diretamente
if __name__ == '__main__':
    unittest.main(exit=False)
    print("Testes concluídos com sucesso!")

