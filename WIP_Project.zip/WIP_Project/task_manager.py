import sqlite3
import tkinter as tk
from tkinter import ttk
from tkinter import simpledialog

class GerenciadorTarefas:
    def __init__(self, root):
        self.root = root
        self.root.title("Gerenciador de Tarefas")
        self.root.geometry("800x600")

        # Configurar o estilo do treeview
        style = ttk.Style()
        style.configure("Treeview", font=('Helvetica', 12))
        style.configure("Treeview.Heading", font=('Helvetica', 14, 'bold'))

        # Configurar o banco de dados
        self.setup_db()

        # Componentes da interface gráfica
        self.setup_widgets()

    def setup_db(self):
        self.conn = sqlite3.connect("tarefas.db")
        self.cursor = self.conn.cursor()
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS tarefas (
                id INTEGER PRIMARY KEY, 
                tarefa TEXT, 
                responsavel TEXT,
                status TEXT, 
                progresso INTEGER)
            """)
        self.conn.commit()

    def setup_widgets(self):
        # Frame para os botões
        frame_botoes = ttk.Frame(self.root)
        frame_botoes.pack(side=tk.TOP, fill=tk.X, padx=10, pady=10)

        # Botões para gerenciamento de tarefas
        botao_adicionar = ttk.Button(frame_botoes, text="Adicionar Tarefa", command=self.adicionar_tarefa)
        botao_adicionar.pack(side=tk.LEFT, padx=10)
        botao_atualizar = ttk.Button(frame_botoes, text="Atualizar Progresso", command=self.atualizar_progresso_tarefa)
        botao_atualizar.pack(side=tk.LEFT, padx=10)

        # Treeview para exibição de tarefas
        self.tree = ttk.Treeview(self.root, columns=('ID', 'Tarefa', 'Responsável', 'Status', 'Progresso'), show='headings')
        self.tree.heading('ID', text='ID')
        self.tree.heading('Tarefa', text='Tarefa')
        self.tree.heading('Responsável', text='Responsável')
        self.tree.heading('Status', text='Status')
        self.tree.heading('Progresso', text='Progresso')
        self.tree.column('ID', width=50, anchor='center')
        self.tree.column('Tarefa', width=200, anchor='w')
        self.tree.column('Responsável', width=120, anchor='w')
        self.tree.column('Status', width=100, anchor='center')
        self.tree.column('Progresso', width=70, anchor='center')
        self.tree.pack(fill=tk.BOTH, expand=True)

        self.carregar_tarefas()

    def carregar_tarefas(self):
        self.tree.delete(*self.tree.get_children())
        for row in self.cursor.execute("SELECT id, tarefa, responsavel, status, progresso FROM tarefas"):
            self.tree.insert('', tk.END, values=row)

    def adicionar_tarefa(self):
        # Diálogo para inserir nova tarefa
        tarefa = simpledialog.askstring("Tarefa", "Informe o nome da tarefa:")
        responsavel = simpledialog.askstring("Responsável", "Quem é responsável por esta tarefa?")
        if tarefa and responsavel:
            # Status e progresso padrão
            status = "Não iniciada"
            progresso = 0
            self.cursor.execute("INSERT INTO tarefas (tarefa, responsavel, status, progresso) VALUES (?, ?, ?, ?)", 
                                (tarefa, responsavel, status, progresso))
            self.conn.commit()
            self.carregar_tarefas()  # Recarregar tarefas

    def atualizar_progresso_tarefa(self):
        item_selecionado = self.tree.selection()
        if item_selecionado:
            item = self.tree.item(item_selecionado)
            progresso = simpledialog.askinteger("Progresso", "Informe o novo progresso:", minvalue=0, maxvalue=100)
            if progresso is not None:
                self.cursor.execute("UPDATE tarefas SET progresso = ? WHERE id = ?", (progresso, item['values'][0]))
                self.conn.commit()
                self.carregar_tarefas()  # Recarregar tarefas

# O código abaixo para iniciar a GUI será descomentado no script final.
root = tk.Tk()
app = GerenciadorTarefas(root)
root.mainloop()